package com.example.soc_macmini_15.musicplayer;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface LastFmService {
    @GET("?method=artist.search&format=json")
    Call<LastFmResponse> searchArtist(@Query("artist") String artistName, @Query("api_key") String apiKey);

    @GET("2.0/")
    Call<LastFmResponse> getArtists(
            @Query("method") String method,
            @Query("artist") String artist,
            @Query("api_key") String apiKey,
            @Query("format") String format
    );

}

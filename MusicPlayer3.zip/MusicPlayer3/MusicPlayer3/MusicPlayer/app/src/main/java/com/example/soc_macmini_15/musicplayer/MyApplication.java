package com.example.soc_macmini_15.musicplayer;

import android.app.Application;

import com.example.soc_macmini_15.musicplayer.Activity.ChangeThemeActivity;

public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        new ChangeThemeActivity().applySavedTheme();
    }
}

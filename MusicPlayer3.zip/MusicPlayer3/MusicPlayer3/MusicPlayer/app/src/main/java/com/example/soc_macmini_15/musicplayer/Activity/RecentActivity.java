package com.example.soc_macmini_15.musicplayer.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import com.example.soc_macmini_15.musicplayer.Adapter.SongAdapter;
import com.example.soc_macmini_15.musicplayer.Model.SongsList;
import com.example.soc_macmini_15.musicplayer.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class RecentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recent);

        ListView listView = findViewById(R.id.list_playlist);

        String historyJson = getIntent().getStringExtra("PLAY_HISTORY");
        if (historyJson != null) {
            Gson gson = new Gson();
            Type listType = new TypeToken<ArrayList<SongsList>>() {}.getType();
            ArrayList<SongsList> recentSongs = gson.fromJson(historyJson, listType);

            // Use the existing SongAdapter
            SongAdapter adapter = new SongAdapter(this, recentSongs);
            listView.setAdapter(adapter);
        }
        Button backButton = findViewById(R.id.recent_backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Close this activity and return to MainActivity
            }
        });

    }

}

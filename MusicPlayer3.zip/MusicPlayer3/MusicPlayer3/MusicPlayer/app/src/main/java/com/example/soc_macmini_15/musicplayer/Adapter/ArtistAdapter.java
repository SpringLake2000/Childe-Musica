package com.example.soc_macmini_15.musicplayer.Adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
//import android.annotation.NonNull;
//import android.recyclerview.widget.RecyclerView;

import com.example.soc_macmini_15.musicplayer.LastFmResponse;
import com.example.soc_macmini_15.musicplayer.R;

import java.util.List;

public class ArtistAdapter extends RecyclerView.Adapter<ArtistAdapter.ArtistViewHolder> {
    private List<LastFmResponse.Results.ArtistMatches.Artist> artistList;
    public ArtistAdapter(List<LastFmResponse.Results.ArtistMatches.Artist> artistList) {
        this.artistList = artistList;
    }

    @NonNull
    @Override
    public ArtistViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_artist, parent, false);
        return new ArtistViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ArtistViewHolder holder, int position) {
        LastFmResponse.Results.ArtistMatches.Artist artist = artistList.get(position);
        holder.artistName.setText(artist.name);}

    @Override
    public int getItemCount() {
        return artistList.size();
    }
    static class ArtistViewHolder extends RecyclerView.ViewHolder {
        TextView artistName;
        public ArtistViewHolder(@NonNull View itemView) {
            super(itemView);
            artistName = itemView.findViewById(R.id.artistName); // ID from item_artist.xml
        }
    }
}

package com.example.soc_macmini_15.musicplayer.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.soc_macmini_15.musicplayer.Adapter.ArtistAdapter;
import com.example.soc_macmini_15.musicplayer.LastFmResponse;
import com.example.soc_macmini_15.musicplayer.R;
import com.google.gson.Gson;

import java.util.List;

public class FmApiResultActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ArtistAdapter artistAdapter;
    private List<LastFmResponse.Results.ArtistMatches.Artist> artistList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fm_api_result);

        //button
        Button backButton = findViewById(R.id.api_backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Get the artist list passed from the Intent
        Intent intent = getIntent();
        String artistJson = intent.getStringExtra("ARTIST_LIST");

        if (artistJson != null) {
            Gson gson = new Gson();
            LastFmResponse.Results.ArtistMatches artistMatches = gson.fromJson(artistJson, LastFmResponse.Results.ArtistMatches.class);
            List<LastFmResponse.Results.ArtistMatches.Artist> artistList = artistMatches.artist;

            artistAdapter = new ArtistAdapter(artistList);
            recyclerView.setAdapter(artistAdapter);
        } else {
            Log.e("FmApiResultActivity", "No artist data found in the intent");
        }
    }

    @Override
    public void onBackPressed() {
        // Return to MainActivity when back is pressed
        Intent intent = new Intent(FmApiResultActivity.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }
}

package com.example.soc_macmini_15.musicplayer;

import java.util.List;

public class LastFmResponse {
    public Results results;

    public static class Results {
        public ArtistMatches artistmatches;

        public static class ArtistMatches {
            public List<Artist> artist;

            public class Artist {
                public String name;
                public String url;
                public String imageUrl;
            }
        }
    }
}
